<p align="center">
  <img src="examples/sample_output.png" alt="Sample Infographic" width="640">
</p>

<h1 align="center">pdf-to-infographic</h1>

<p align="center">
  WorkBuddy Skill &mdash; Transform any academic PDF into a hand-drawn cartoon infographic.
</p>

<p align="center">
  <a href="#install">Install</a> &middot;
  <a href="#usage">Usage</a> &middot;
  <a href="#how-it-works">Pipeline</a> &middot;
  <a href="#standalone-cli">Standalone CLI</a> &middot;
  <a href="#configuration">Configuration</a>
</p>

---

## Install

```bash
npx skills add https://github.com/jiaqihriver/pdf-to-infographic
```

Or manually: copy `SKILL.md` into `~/.workbuddy/skills/pdf-to-infographic/`.

## What This Skill Does

Takes a PDF paper as input and produces a hand-drawn cartoon-style infographic (PNG) as output. The workflow is fully automated inside WorkBuddy:

1. Extract text from PDF (CJK-safe via PyMuPDF rawdict)
2. Analyze content structure (title, sections, key numbers)
3. Construct an image generation prompt
4. Generate the infographic via WorkBuddy's built-in ImageGen

No manual prompt writing required. No external API key needed when running inside WorkBuddy.

## Usage

Inside a WorkBuddy conversation, just say:

> "帮我根据这篇论文生成一张信息图 @paper.pdf"

The skill will activate and run the full pipeline automatically.

### What you get

- A `1536x1024` landscape PNG in hand-drawn cartoon style
- Soft pastel palette, thick black outlines, doodle icons
- Content organized in a 2x3 grid with clear section labels
- Key data points displayed as large "data hero" figures
- All text in the paper's language (Chinese or English auto-detected)

### Customization

You can ask for adjustments after the first generation:

> "换个科技蓝配色" / "加上更多数据对比" / "用英文版"

The skill will revise the prompt and regenerate.

## How It Works

```
PDF ──[Step 1]──> extracted_text.txt
                          │
                   [Step 2] (Content Analysis)
                          │
                   content_summary.json
                          │
                   [Step 3] (Prompt Builder)
                          │
                   prompt.txt
                          │
                   [Step 4] (ImageGen)
                          │
                   infographic.png
```

| Step | Description | Tool |
|:----:|-------------|------|
| 1 | Extract text via PyMuPDF `rawdict` mode | Python (pymupdf) |
| 2 | Detect language, identify sections, extract key numbers | Python (heuristic) |
| 3 | Convert structured analysis into image prompt | Python (template) |
| 4 | Generate infographic | WorkBuddy ImageGen |

### CJK Handling (Step 1)

Standard `page.get_text()` often garbles Chinese/Japanese/Korean text due to font encoding issues. This skill uses `page.get_text("rawdict")` which reads individual character Unicode codepoints directly, producing clean output regardless of the PDF's font embedding.

## Standalone CLI

The pipeline scripts work outside WorkBuddy too. Clone this repo and run:

```bash
pip install -r requirements.txt

# Prompt only (no API key needed)
python run_pipeline.py paper.pdf ./output --prompt-only

# Full pipeline (requires OPENAI_API_KEY)
python run_pipeline.py paper.pdf ./output
```

### Run Steps Individually

```bash
python scripts/extract_pdf.py         paper.pdf         ./output/text.txt
python scripts/analyze_content.py     ./output/text.txt ./output/summary.json
python scripts/build_prompt.py        ./output/summary.json ./output/prompt.txt
python scripts/generate_infographic.py ./output/prompt.txt ./output
```

This gives you full control -- edit the JSON or prompt between steps for best results.

## Configuration

### Environment Variables (Standalone CLI only)

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | *(none)* | OpenAI (or compatible) API key |
| `OPENAI_BASE_URL` | OpenAI default | Override for Azure / local endpoints |
| `IMAGE_MODEL` | `gpt-image-1` | Model identifier |
| `IMAGE_SIZE` | `1536x1024` | Canvas size |
| `IMAGE_QUALITY` | `high` | `low` / `medium` / `high` |

### Inside WorkBuddy

No configuration needed. The skill uses WorkBuddy's built-in `ImageGen` deferred tool with these defaults:

- `size`: `"1536x1024"`
- `quality`: `"high"`
- `style`: `"natural"`

## Examples

The `examples/` directory contains a real output generated from:

> **《中国英语能力等级量表》研究综述** -- Li & Gu (2019), *Foreign Languages and Translation*

| File | Description |
|------|-------------|
| `examples/sample_summary.json` | Content analysis output (Step 2) |
| `examples/sample_prompt.txt` | Generated image prompt (Step 3) |
| `examples/sample_output.png` | Final infographic (Step 4) |

## Project Structure

```
pdf-to-infographic/
├── SKILL.md                          # WorkBuddy skill definition (auto-install)
├── README.md                         # This file
├── LICENSE                           # MIT
├── requirements.txt                  # pymupdf, openai, Pillow
├── run_pipeline.py                   # One-shot CLI wrapper
├── scripts/
│   ├── extract_pdf.py                # Step 1: PDF -> text (rawdict CJK fix)
│   ├── analyze_content.py            # Step 2: text -> JSON summary
│   ├── build_prompt.py               # Step 3: JSON -> image prompt
│   └── generate_infographic.py       # Step 4: prompt -> PNG (OpenAI API)
├── examples/
│   ├── sample_summary.json
│   ├── sample_prompt.txt
│   └── sample_output.png
└── docs/
    └── WORKBUDDY_SKILL.md            # WorkBuddy integration notes
```

## Contributing

PRs welcome! Ideas:

- [ ] LLM-powered content analysis (replace heuristic Step 2)
- [ ] Streamlit / Gradio web UI
- [ ] Additional style presets (minimal, neon, blueprint, etc.)
- [ ] Multi-page infographic support

## License

MIT
