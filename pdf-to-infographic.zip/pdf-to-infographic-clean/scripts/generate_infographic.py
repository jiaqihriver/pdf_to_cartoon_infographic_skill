#!/usr/bin/env python3
"""
generate_infographic.py — Step 4 (optional local variant): Call an
OpenAI-compatible image generation API with the prompt produced in Step 3.

Usage:
    python scripts/generate_infographic.py <prompt.txt> [output_dir]

Environment variables:
    OPENAI_API_KEY   — your OpenAI (or compatible) API key
    OPENAI_BASE_URL  — optional, override the API base URL
                       (e.g. for Azure, local Stable Diffusion, etc.)
    IMAGE_MODEL      — model name, default "gpt-image-1"
    IMAGE_SIZE       — image size, default "1536x1024"
    IMAGE_QUALITY    — "low" | "medium" | "high", default "high"

The script saves the resulting image as a PNG in <output_dir>
(defaults to ./output/).

Dependencies:
    pip install openai pillow

Notes:
    When running inside WorkBuddy / CodeBuddy, you can skip this script and
    use the built-in ImageGen deferred tool directly — see README.md.
"""

import os
import sys
import base64
import pathlib
import datetime

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai package not installed. Run: pip install openai", file=sys.stderr)
    sys.exit(1)

try:
    from PIL import Image
    import io as _io
    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False


def generate(prompt: str, output_dir: str = "./output") -> str:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("ERROR: OPENAI_API_KEY environment variable is not set.", file=sys.stderr)
        sys.exit(1)

    base_url = os.environ.get("OPENAI_BASE_URL")
    model = os.environ.get("IMAGE_MODEL", "gpt-image-1")
    size = os.environ.get("IMAGE_SIZE", "1536x1024")
    quality = os.environ.get("IMAGE_QUALITY", "high")

    client_kwargs = {"api_key": api_key}
    if base_url:
        client_kwargs["base_url"] = base_url
    client = OpenAI(**client_kwargs)

    print(f"[generate] Calling model={model}, size={size}, quality={quality} …")
    response = client.images.generate(
        model=model,
        prompt=prompt,
        size=size,
        quality=quality,
        n=1,
        response_format="b64_json",
    )

    image_data = base64.b64decode(response.data[0].b64_json)

    pathlib.Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = pathlib.Path(output_dir) / f"infographic_{timestamp}.png"

    if HAS_PILLOW:
        img = Image.open(_io.BytesIO(image_data))
        img.save(out_path, "PNG")
    else:
        out_path.write_bytes(image_data)

    print(f"[generate] Image saved to: {out_path}")
    return str(out_path)


def main():
    if len(sys.argv) < 2:
        print("Usage: python generate_infographic.py <prompt.txt> [output_dir]")
        sys.exit(1)

    prompt_path = sys.argv[1]
    if not pathlib.Path(prompt_path).exists():
        print(f"ERROR: File not found: {prompt_path}", file=sys.stderr)
        sys.exit(1)

    prompt = pathlib.Path(prompt_path).read_text(encoding="utf-8")
    output_dir = sys.argv[2] if len(sys.argv) >= 3 else "./output"
    generate(prompt, output_dir)


if __name__ == "__main__":
    main()
