#!/usr/bin/env python3
"""
build_prompt.py — Step 3: Convert a content-summary JSON into an ImageGen
prompt string optimised for the hand-drawn cartoon infographic style.

Usage:
    python scripts/build_prompt.py <content_summary.json> [output_prompt.txt]

The generated prompt is ready to paste into any text-to-image API that
supports detailed natural-language prompts (e.g. GPT-image-1, DALL-E 3,
Stable Diffusion, Hunyuan, etc.).

Prompt conventions used:
    - Landscape 16:9 (1536x1024 recommended)
    - Hand-drawn / sketch style, thick black outlines, soft pastel palette
    - All body text in Chinese (or English, auto-detected from JSON)
    - Sections arranged in a 2×3 or 3×2 grid
    - Key numbers displayed as large "data hero" figures
"""

import sys
import json
import pathlib

STYLE_SUFFIX = (
    "Style: hand-drawn sketch illustration, thick black outlines, soft pastel colors "
    "(pale yellow, light blue, soft green, blush pink), doodle icons, generous "
    "whitespace, slightly imperfect lines, warm academic aesthetic. "
    "No photorealistic elements. Clean layout with visible section borders. "
    "All text rendered in hand-lettered style."
)


def sections_to_text(sections: list, language: str) -> str:
    parts = []
    positions = [
        "TOP LEFT", "TOP CENTER", "TOP RIGHT",
        "BOTTOM LEFT", "BOTTOM CENTER", "BOTTOM RIGHT",
    ]
    for i, sec in enumerate(sections[:6]):
        pos = positions[i] if i < len(positions) else f"SECTION {i+1}"
        label = sec.get("label", f"Section {i+1}")
        points = sec.get("points", [])
        icon = sec.get("icon", "")
        bullets = "; ".join(f'"{p}"' for p in points[:3]) if points else ""
        parts.append(
            f"{i+1}. {pos} — '{label}' section {icon}: {bullets}."
        )
    return "\n".join(parts)


def numbers_to_text(key_numbers: list) -> str:
    if not key_numbers:
        return ""
    items = []
    for n in key_numbers[:4]:
        items.append(f"{n['value']}{n['unit']} ({n['description'][:40]})")
    return "Prominently feature key data: " + ", ".join(items) + "."


def build_prompt(summary: dict) -> str:
    title = summary.get("title", "Research Review")
    subtitle = summary.get("subtitle", "")
    language = summary.get("language", "zh")
    lang_label = "Chinese" if language == "zh" else "English"
    sections = summary.get("sections", [])
    key_numbers = summary.get("key_numbers", [])

    header = (
        f"A hand-drawn cartoon infographic about '{title}', landscape 16:9 format.\n\n"
        f"Title: '{title}' in bold hand-lettered style at the top."
    )
    if subtitle:
        header += f" Subtitle: '{subtitle}'."

    body = "\n\nMain content organised in a 2×3 grid:\n" + sections_to_text(sections, language)

    numbers = "\n\n" + numbers_to_text(key_numbers) if key_numbers else ""

    lang_note = (
        f"\n\nAll text labels and captions must be written in {lang_label}."
    )

    return header + body + numbers + lang_note + "\n\n" + STYLE_SUFFIX


def main():
    if len(sys.argv) < 2:
        print("Usage: python build_prompt.py <content_summary.json> [output_prompt.txt]")
        sys.exit(1)

    json_path = sys.argv[1]
    if not pathlib.Path(json_path).exists():
        print(f"ERROR: File not found: {json_path}", file=sys.stderr)
        sys.exit(1)

    summary = json.loads(pathlib.Path(json_path).read_text(encoding="utf-8"))
    prompt = build_prompt(summary)

    if len(sys.argv) >= 3:
        out_path = sys.argv[2]
        pathlib.Path(out_path).write_text(prompt, encoding="utf-8")
        print(f"[build_prompt] Saved prompt to: {out_path}")
    else:
        print(prompt)


if __name__ == "__main__":
    main()
