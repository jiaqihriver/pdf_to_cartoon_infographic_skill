#!/usr/bin/env python3
"""
extract_pdf.py — Step 1: Extract text from a PDF using PyMuPDF.

Usage:
    python scripts/extract_pdf.py <path/to/paper.pdf> [output.txt]

If no output file is provided, text is printed to stdout.

Notes:
    - Uses rawdict mode to correctly decode CJK (Chinese/Japanese/Korean) fonts
      that would otherwise produce garbled output with the default get_text() call.
    - Extracts up to MAX_PAGES pages (default: all pages).
"""

import sys
import pathlib

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF is not installed. Run: pip install pymupdf", file=sys.stderr)
    sys.exit(1)

MAX_PAGES = None  # Set to an integer to limit page count, e.g. 8


def extract_text(pdf_path: str) -> str:
    """Extract all text from a PDF, handling CJK fonts via rawdict mode."""
    doc = fitz.open(pdf_path)
    total = len(doc) if MAX_PAGES is None else min(MAX_PAGES, len(doc))
    parts = []

    for i in range(total):
        page = doc[i]
        raw = page.get_text("rawdict")
        page_lines = []

        for block in raw["blocks"]:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                line_text = ""
                for span in line["spans"]:
                    for char in span.get("chars", []):
                        c = char.get("c", "")
                        if c:
                            line_text += c
                if line_text.strip():
                    page_lines.append(line_text)

        parts.append(f"\n=== PAGE {i + 1} ===\n" + "\n".join(page_lines))

    return "\n".join(parts)


def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_pdf.py <pdf_path> [output.txt]")
        sys.exit(1)

    pdf_path = sys.argv[1]
    if not pathlib.Path(pdf_path).exists():
        print(f"ERROR: File not found: {pdf_path}", file=sys.stderr)
        sys.exit(1)

    text = extract_text(pdf_path)

    if len(sys.argv) >= 3:
        out_path = sys.argv[2]
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[extract_pdf] Saved extracted text to: {out_path}")
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
