#!/usr/bin/env python3
"""
analyze_content.py — Step 2: Analyze extracted PDF text and output a
structured content summary (JSON) for infographic generation.

Usage:
    python scripts/analyze_content.py <extracted_text.txt> [output.json]

Output JSON schema:
{
  "title":       str,          # infographic headline
  "subtitle":    str,          # author / journal / year
  "core_theme":  str,          # one-sentence description of the paper
  "sections": [
    {
      "id":      str,          # e.g. "background"
      "label":   str,          # display label in Chinese/English
      "points":  [str, ...],   # 2-5 key bullet points
      "icon":    str           # emoji or icon keyword hint
    },
    ...
  ],
  "key_numbers": [
    {"value": str, "unit": str, "description": str},
    ...
  ],
  "language":    str           # "zh" or "en"
}

Notes:
    This script uses heuristic text analysis (no LLM required).
    For best results with academic papers, review and edit the JSON before
    passing it to generate_infographic.py.
"""

import sys
import json
import re
import pathlib


def detect_language(text: str) -> str:
    """Rough language detection based on CJK character ratio."""
    cjk = sum(1 for c in text if "\u4e00" <= c <= "\u9fff")
    return "zh" if cjk / max(len(text), 1) > 0.1 else "en"


def extract_numbers(text: str):
    """Pull out prominent numeric data points."""
    # Match patterns like "68篇", "41.2%", "75%", "2018年"
    patterns = [
        (r"(\d+(?:\.\d+)?)\s*%", "%", "percentage"),
        (r"(\d+)\s*篇", "篇", "documents"),
        (r"(\d{4})\s*年", "年", "year"),
        (r"(\d+)\s*种", "种", "categories"),
    ]
    results = []
    seen = set()
    for pat, unit, desc in patterns:
        for m in re.finditer(pat, text):
            val = m.group(1)
            key = f"{val}{unit}"
            if key not in seen:
                seen.add(key)
                # grab surrounding context (up to 20 chars before the match)
                start = max(0, m.start() - 20)
                context = text[start: m.end() + 20].replace("\n", " ").strip()
                results.append({"value": val, "unit": unit, "description": context})
            if len(results) >= 6:
                break
        if len(results) >= 6:
            break
    return results


def split_sections(text: str):
    """Heuristic: split on numbered headings like '1.', '2.', '3.' or Chinese '一、二、'."""
    # Try Arabic-numbered sections first
    chunks = re.split(r"\n(?=\d+[\.、]\s)", text)
    if len(chunks) < 3:
        # Fall back to page boundaries
        chunks = re.split(r"=== PAGE \d+ ===", text)
    return [c.strip() for c in chunks if len(c.strip()) > 50]


def build_summary(text: str) -> dict:
    lang = detect_language(text)

    # Title: first non-empty line that looks like a title (short, no trailing punctuation)
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    title = ""
    subtitle = ""
    for l in lines[:20]:
        if 4 < len(l) < 50 and not l.endswith("。") and not l.startswith("==="):
            if not title:
                title = l
            elif not subtitle:
                subtitle = l
                break

    key_numbers = extract_numbers(text)
    sections_raw = split_sections(text)

    # Build generic sections from the first 6 chunks
    icons = ["📋", "📊", "👥", "🔬", "📝", "💡"]
    sections = []
    for i, chunk in enumerate(sections_raw[:6]):
        chunk_lines = [l.strip() for l in chunk.split("\n") if l.strip()]
        label = chunk_lines[0][:30] if chunk_lines else f"Section {i+1}"
        points = [l for l in chunk_lines[1:] if len(l) > 5][:4]
        sections.append({
            "id": f"section_{i+1}",
            "label": label,
            "points": points,
            "icon": icons[i % len(icons)],
        })

    return {
        "title": title,
        "subtitle": subtitle,
        "core_theme": f"Research review of: {title}",
        "sections": sections,
        "key_numbers": key_numbers,
        "language": lang,
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze_content.py <text_file> [output.json]")
        sys.exit(1)

    text_path = sys.argv[1]
    if not pathlib.Path(text_path).exists():
        print(f"ERROR: File not found: {text_path}", file=sys.stderr)
        sys.exit(1)

    text = pathlib.Path(text_path).read_text(encoding="utf-8")
    summary = build_summary(text)

    out = json.dumps(summary, ensure_ascii=False, indent=2)

    if len(sys.argv) >= 3:
        out_path = sys.argv[2]
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"[analyze_content] Saved content summary to: {out_path}")
    else:
        print(out)


if __name__ == "__main__":
    main()
