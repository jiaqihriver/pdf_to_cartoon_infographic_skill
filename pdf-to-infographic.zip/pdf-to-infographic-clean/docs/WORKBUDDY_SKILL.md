# WorkBuddy Skill Notes — pdf-to-infographic

## Skill Overview

This toolkit was extracted from a WorkBuddy skill that automates the full
PDF → infographic pipeline inside a WorkBuddy / CodeBuddy session.

## Using the Skill in WorkBuddy

The corresponding WorkBuddy skill (`pdf-to-infographic`) is stored at:

```
~/.workbuddy/skills/pdf-to-infographic/
```

To invoke it, mention it in your conversation:

```
@skill:pdf-to-infographic @"/path/to/paper.pdf" 帮我生成一张信息图
```

## Key Implementation Notes for Skill Authors

### 1. CJK Font Extraction

Standard `page.get_text()` returns garbled output for many Chinese PDFs
because they use embedded CID/Type0 fonts with private encoding tables.

**Fix:** use `rawdict` mode and iterate over the `chars` array:

```python
raw = page.get_text("rawdict")
for block in raw["blocks"]:
    for line in block.get("lines", []):
        for span in line["spans"]:
            for char in span.get("chars", []):
                c = char.get("c", "")   # ← correct Unicode codepoint
```

### 2. ImageGen Call

Inside WorkBuddy, use `DeferExecuteTool` → `ImageGen`:

```python
DeferExecuteTool(
    toolName="ImageGen",
    params={
        "prompt": "<constructed_prompt>",
        "size": "1536x1024",   # 16:9 landscape
        "quality": "high",
        "style": "natural",
        "output_dir": "<workspace>/paper_images"
    }
)
```

### 3. Prompt Structure

The prompt must specify:
- Landscape 16:9 format explicitly
- A 2×3 grid with named positions (TOP LEFT / TOP CENTER / …)
- Hand-drawn sketch style with specific color palette
- Language for all text labels
- Central visual or "data hero" number for visual hierarchy

### 4. Typical Workflow (8 tool calls)

1. `TaskCreate` × 3 (track steps)
2. `Bash` — install/verify pymupdf
3. `Write` + `Bash` — extract PDF text via rawdict
4. `Read` — load extracted text into context
5. (Mental analysis — no tool call)
6. `ToolSearch` → find ImageGen
7. `DeferExecuteTool` → ImageGen (Step 4)
8. `deliver_attachments` → deliver PNG to user
