#!/usr/bin/env python3
"""
run_pipeline.py — One-shot convenience wrapper that runs all four steps:
    1. extract_pdf.py      → extracted_text.txt
    2. analyze_content.py  → content_summary.json
    3. build_prompt.py     → prompt.txt
    4. generate_infographic.py  → output/<timestamp>.png

Usage:
    python run_pipeline.py <path/to/paper.pdf> [output_dir]

    output_dir defaults to ./output/

Environment variables (for Step 4):
    OPENAI_API_KEY, OPENAI_BASE_URL, IMAGE_MODEL, IMAGE_SIZE, IMAGE_QUALITY
    (see generate_infographic.py for details)

Quick start (skip image generation — just build the prompt):
    python run_pipeline.py paper.pdf --prompt-only
"""

import sys
import pathlib
import subprocess
import tempfile
import os

SCRIPTS = pathlib.Path(__file__).parent / "scripts"


def run(cmd: list, **kwargs):
    result = subprocess.run(cmd, check=True, **kwargs)
    return result


def main():
    if len(sys.argv) < 2:
        print("Usage: python run_pipeline.py <pdf_path> [output_dir] [--prompt-only]")
        sys.exit(1)

    pdf_path = sys.argv[1]
    prompt_only = "--prompt-only" in sys.argv
    output_dir = next(
        (a for a in sys.argv[2:] if not a.startswith("--")), "./output"
    )

    pathlib.Path(output_dir).mkdir(parents=True, exist_ok=True)

    txt_out = str(pathlib.Path(output_dir) / "extracted_text.txt")
    json_out = str(pathlib.Path(output_dir) / "content_summary.json")
    prompt_out = str(pathlib.Path(output_dir) / "prompt.txt")

    python = sys.executable

    print("=" * 60)
    print("Step 1/4 — Extracting text from PDF …")
    run([python, str(SCRIPTS / "extract_pdf.py"), pdf_path, txt_out])

    print("\nStep 2/4 — Analysing content …")
    run([python, str(SCRIPTS / "analyze_content.py"), txt_out, json_out])

    print("\nStep 3/4 — Building image prompt …")
    run([python, str(SCRIPTS / "build_prompt.py"), json_out, prompt_out])

    print(f"\n✅  Prompt written to: {prompt_out}")

    if prompt_only:
        print("\n[--prompt-only] Skipping image generation.")
        print("Edit the prompt if needed, then run:")
        print(f"    python scripts/generate_infographic.py {prompt_out} {output_dir}")
        return

    if not os.environ.get("OPENAI_API_KEY"):
        print(
            "\n⚠️  OPENAI_API_KEY not set — skipping image generation.\n"
            "Set the variable and re-run, or use --prompt-only to skip this step."
        )
        return

    print("\nStep 4/4 — Generating infographic …")
    run([python, str(SCRIPTS / "generate_infographic.py"), prompt_out, output_dir])
    print("\n🎉  Pipeline complete!")


if __name__ == "__main__":
    main()
